package com.formacionbdi.microservicios.app.cursos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroserviciosCursosApplicationTests {

	@Test
	void contextLoads() {
	}

}
