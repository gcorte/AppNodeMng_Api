package com.formacionbdi.microservicios.commons.examenes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CommonsExamenesApplicationTests {

	@Test
	void contextLoads() {
	}

}
